<?php echo $__env->make('plantillas.encabezado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body>

    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>

    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

        <?php echo $__env->make('plantillas.encabezado2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('plantillas.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="page-wrapper">

            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">INICIO</h4>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">
                                    Mapa de Alertas
                                </h4>
                                <div id="mapa" style="height:600px;border-radius:10px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('plantillas.pie', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        // Crear mapa
        var mapa = L.map('mapa').setView([-17.3935, -66.1570], 13);
        // Capa base
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(mapa);
        // Iconos
        var iconoRojo = new L.Icon({
            iconUrl: "<?php echo e(asset('images/marker-icon-red.png')); ?>",
            shadowUrl: "<?php echo e(asset('images/marker-shadow.png')); ?>",
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });
        var iconoAmarillo = new L.Icon({
            iconUrl: "<?php echo e(asset('images/marker-icon-gold.png')); ?>",
            shadowUrl: "<?php echo e(asset('images/marker-shadow.png')); ?>",
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });
        var iconoVerde = new L.Icon({
            iconUrl: "<?php echo e(asset('images/marker-icon-green.png')); ?>",
            shadowUrl: "<?php echo e(asset('images/marker-shadow.png')); ?>",
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });
        <?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    var punto = "<?php echo e($reporte->ubicacion); ?>".split(",");
                    var icono = iconoRojo;
                    if ("<?php echo e($reporte->estado); ?>" == "En Proceso") {
                        icono = iconoAmarillo;
                    }
                    if ("<?php echo e($reporte->estado); ?>" == "Solucionado") {
                        icono = iconoVerde;
                    }
                    L.marker([punto[0], punto[1]], {
                        icon: icono
                    })
                        .addTo(mapa)
                        .bindPopup(`
            <div style="
                width:230px;
                font-family:Arial,sans-serif;
            ">

                <?php if($reporte->imagen): ?>
                    <img
                        src="<?php echo e(asset('storage/' . $reporte->imagen)); ?>"
                        style="
                            width:100%;
                            height:130px;
                            object-fit:cover;
                            border-radius:8px;
                            margin-bottom:8px;
                        ">
                <?php endif; ?>
                <a href="/reportes/pdf/<?php echo e($reporte->idReporte); ?>"
                    target="_blank"
                    style="
                        text-decoration:none;
                        color:#0d6efd;
                        font-size:16px;
                        font-weight:bold;">
                    <?php echo e($reporte->titulo); ?>

                </a>
                <hr style="margin:8px 0;">
                <div style="font-size:13px;">
                    <b>Categoría</b><br>
                    <?php echo e($reporte->categoria); ?>

                </div>
                <div style="margin-top:6px;font-size:13px;">
                    <b>Dirección</b><br>
                    <?php echo e($reporte->direccion); ?>

                </div>
                <div style="margin-top:10px;">
                    <span style="
                        padding:4px 10px;
                        border-radius:20px;
                        color:white;
                        font-size:11px;
                        font-weight:bold;
                        background:
                        <?php if($reporte->estado == 'Pendiente'): ?>
                            #dc3545
                        <?php elseif($reporte->estado == 'En Proceso'): ?>
                            #ffc107
                        <?php else: ?>
                            #198754
                        <?php endif; ?>;
                    ">
                        <?php echo e($reporte->estado); ?>

                    </span>
                </div>

            </div>
            `);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    <?php echo $__env->make('plantillas.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\GestionDeAlertas\resources\views/inicio/index.blade.php ENDPATH**/ ?>