<?php echo $__env->make('plantillas.encabezado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php echo $__env->make('plantillas.encabezado2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('plantillas.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="page-wrapper">
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="row align-items-center">
                        <div class="col-lg-3">
                            <h4 class="page-title">REPORTES</h4>
                        </div>
                        <div class="col-lg-9 text-end">
                            <?php if(session('rol') == 'Administrador'): ?>
                                <a href="/reportes/pdf-todos" target="_blank" class="btn btn-primary">
                                    <i class="fa fa-file-pdf"></i>
                                    Exportar todos
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-4">
                            Lista de Reportes
                        </h4>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Título</th>
                                        <th>Categoría</th>
                                        <th>Estado</th>
                                        <th>Foto</th>
                                        <th>Usuario</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($reporte->titulo); ?></td>
                                            <td><?php echo e($reporte->nombre); ?></td>
                                            <td>
                                                <?php if($reporte->estado == "Pendiente"): ?>
                                                    <span class="badge bg-danger">
                                                        Pendiente
                                                    </span>
                                                <?php elseif($reporte->estado == "En Proceso"): ?>
                                                    <span class="badge bg-warning text-dark">
                                                        En Proceso
                                                    </span>
                                                <?php elseif($reporte->estado == "Resuelto"): ?>
                                                    <span class="badge bg-success">
                                                        Resuelto
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($reporte->imagen): ?>
                                                    <img src="<?php echo e(asset('storage/' . $reporte->imagen)); ?>" alt="Foto del reporte"
                                                        width="80" height="60" style="object-fit: cover; border-radius: 5px;">
                                                <?php else: ?>
                                                    <span class="text-muted">Sin foto</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($reporte->usuario); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('/reportes/pdf/' . $reporte->idReporte)); ?>" target="_blank"
                                                    class="btn btn-primary btn-sm" title="Ver reporte en PDF">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                                <?php if(session('rol') == 'Administrador'): ?>
                                                    <a href="/reportes/editar/<?php echo e($reporte->idReporte); ?>"
                                                        class="btn btn-warning btn-sm" title="Editar">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <button class="btn btn-light btn-sm" data-bs-toggle="modal"
                                                    data-bs-target="#modalEliminar"
                                                    onclick="confirmarEliminar('<?php echo e($reporte->titulo); ?>','/reportes/eliminar/<?php echo e($reporte->idReporte); ?>')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('plantillas.pie', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Modal Eliminar -->
            <div class="modal fade" id="modalEliminar" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-secondary text-dark">
                            <h5 class="modal-title">
                                Confirmar eliminación
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                            </button>
                        </div>
                        <div class="modal-body">
                            <h5 id="nombreRegistro"></h5>
                            <p class="text-muted">
                                Esta acción no se puede deshacer.
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-bs-dismiss="modal">
                                Cancelar
                            </button>
                            <a id="btnEliminar" class="btn btn-danger">
                                Eliminar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('plantillas.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script>
        function confirmarEliminar(nombre, url) {
            document.getElementById("nombreRegistro").innerHTML =
                "¿Eliminar <b>" + nombre + "</b>?"
            document.getElementById("btnEliminar").href = url;
        }
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\GestionDeAlertas\resources\views/reportes/reportes.blade.php ENDPATH**/ ?>