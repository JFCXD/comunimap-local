<footer class="footer text-center"> 2021 © Ample Admin brought to you by <a
                    href="https://www.wrappixel.com/">wrappixel.com</a>
            </footer><?php /**PATH C:\xampp\htdocs\GestionDeAlertas\resources\views/plantillas/pie.blade.php ENDPATH**/ ?>